﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
	[TestClass]
	public class AdminTest
	{
		[TestMethod]
		public void TestMethod1()
		{
		}
	}
}
