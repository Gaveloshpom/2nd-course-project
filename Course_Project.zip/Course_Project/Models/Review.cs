﻿using System;
using Newtonsoft.Json;

namespace Course_Project.Models
{
    [JsonObject]
    public class Review
    {
        [JsonProperty]
        public int Rating { get; set; } // від 1 до 5

        [JsonProperty]
        public string Text { get; set; }

        [JsonProperty]
        public RegisteredUser Author { get; set; }

        [JsonProperty]
        public DateTime Date { get; set; }
    }
}

